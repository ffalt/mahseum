https://web.archive.org/web/20231204163740/https://cynagames.com/kyoextra.html

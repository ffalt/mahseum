https://web.archive.org/web/19981205213424/http://www.kaser.com/solitile.html

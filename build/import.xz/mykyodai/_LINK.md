https://web.archive.org/web/20060910220158/http://homepage.ntlworld.com/enemyskies/mykyodai/layouts_all.zip

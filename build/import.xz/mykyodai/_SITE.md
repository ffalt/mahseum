https://web.archive.org/web/20080704134618/http://homepage.ntlworld.com/enemyskies/mykyodai/green/layouts.html

https://web.archive.org/web/20040506174312/http://www.haywired.com/mugwump/layouts.html

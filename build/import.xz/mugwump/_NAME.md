Mugwump Dillard

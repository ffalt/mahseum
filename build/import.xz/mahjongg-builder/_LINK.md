https://github.com/shadowmoon-waltz/MahjonggBuilder/tree/master/app/src/main/res/raw/

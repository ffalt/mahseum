https://github.com/phileimer/xmahjongg/tree/main/share/layouts/

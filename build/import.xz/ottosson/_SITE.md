https://web.archive.org/web/20190804145400/http://www.angelfire.com/mo2/ottosson/layouts.html

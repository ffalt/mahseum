https://web.archive.org/web/20190804145429/http://www.angelfire.com/mo2/ottosson/layouts/12bars.zip

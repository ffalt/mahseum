https://web.archive.org/web/20190804145425/http://www.angelfire.com/mo2/ottosson/layouts/6x24.zip

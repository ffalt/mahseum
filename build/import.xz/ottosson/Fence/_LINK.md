https://web.archive.org/web/20190804145426/http://www.angelfire.com/mo2/ottosson/layouts/Fence.zip

https://web.archive.org/web/20190804145428/http://www.angelfire.com/mo2/ottosson/layouts/6bars.zip

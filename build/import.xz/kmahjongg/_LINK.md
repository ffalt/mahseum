https://github.com/KDE/kmahjongg/tree/master/layouts/

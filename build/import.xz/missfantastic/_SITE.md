https://web.archive.org/web/20030820172841/http://www.missfantastic.com/mahjongg/layouts/

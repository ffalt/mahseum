https://web.archive.org/web/20030907053712/http://www.missfantastic.com/mahjongg/layouts/

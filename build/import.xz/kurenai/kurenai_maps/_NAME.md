Maps and flags

https://web.archive.org/web/20230204113220/http://tsubassa-kurenai.de/Kyodai/Layouts/Tile-Layouts.zip

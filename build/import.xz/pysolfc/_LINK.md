https://github.com/shlomif/PySolFC/tree/master/pysollib/games/mahjongg/

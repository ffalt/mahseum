http://sourceforge.net/projects/osrpgcreation/files/Mahjong/1.1.0/ogs-mahjong-1.1.0-linux64.tar.lzma/download

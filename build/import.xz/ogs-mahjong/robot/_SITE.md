https://sourceforge.net/p/osrpgcreation/code/ci/default/tree/tools/LayoutEditor/MyLayouts/robot.layout

https://sourceforge.net/projects/osrpgcreation/files/Mahjong/1.1.0/

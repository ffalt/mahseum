GNOME Mahjongg

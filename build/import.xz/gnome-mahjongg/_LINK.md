https://github.com/GNOME/gnome-mahjongg/tree/main/data/maps/

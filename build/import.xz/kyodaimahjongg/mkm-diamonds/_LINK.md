https://web.archive.org/web/20170903145616mp_/https://kyodaimahjongg.weebly.com/uploads/9/5/2/9/9529146/mkm-diamonds.zip

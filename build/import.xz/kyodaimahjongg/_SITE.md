https://web.archive.org/web/20170903145616/http://kyodaimahjongg.weebly.com/layouts.html

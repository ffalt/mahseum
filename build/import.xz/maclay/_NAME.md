Oneam's Brain Dump

https://web.archive.org/web/20001014101830/http://www.geocities.com/Tokyo/Flats/2958/Maclay.zip

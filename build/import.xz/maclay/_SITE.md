https://web.archive.org/web/20010607211511/http://www.geocities.com/Tokyo/Flats/2958/goodys.html

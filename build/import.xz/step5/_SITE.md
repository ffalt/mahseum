https://web.archive.org/web/20040407182149/http://www.step5.de/step5.htm

https://archive.org/download/MahJongg4.1VariousTileSetsAndBoardsNelsAndersonEtAl.1993/Mahjongg.zip

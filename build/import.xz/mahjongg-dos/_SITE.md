https://archive.org/details/MahJongg4.1VariousTileSetsAndBoardsNelsAndersonEtAl.1993

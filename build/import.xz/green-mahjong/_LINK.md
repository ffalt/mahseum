https://github.com/danbeck/green-mahjong/tree/master/GreenMahjong/www/js/

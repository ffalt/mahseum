https://web.archive.org/web/20040612231847/http://deathm1.tripod.com/stuff/pcgames.html

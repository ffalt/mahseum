https://web.archive.org/web/20040610002141/http://deathm1.tripod.com/stuff/layouts.zip
